# Status

We apply for the badge of type "reusable." We prepared a replication package for the submission (also available on a dedicated website https://sites.google.com/view/empirical-study-robotics-se/home). All our artifacts are documented as requested, so data is not only available but also reusable.