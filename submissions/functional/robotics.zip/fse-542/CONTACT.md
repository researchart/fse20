# Authors list
## Author 1 (corresponding author)
Sergio García
Email: sergio.garcia@gu.se
Github id: SergioGarG

## Author 2
Daniel Strüber 
Email: d.strueber@cs.ru.nl
Github id: dstrueber

## Author 3
Davide Brugali
Email: davide.brugali@unibg.it
Github id: dbrugali

## Author 4
Thorsten Berger
Email: thorsten.berger@chalmers.se
Github id: thorstenberger

## Author 5
Patrizio Pelliccione
Email: patrizio.pelliccione@cse.gu.se
Github id: PatrizioPelliccione